package com.smartattend.app

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputFilter
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.Face
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

private val SUBJ = listOf("Maths", "Physics", "DSA", "DBMS")
private const val TH = 75
private const val MATCH_THRESHOLD = 0.65f // tune with your model and real faces
private val BLUE = 0xFF2D63C0.toInt(); private val INK = 0xFF16203A.toInt(); private val MUTE = 0xFF5D6882.toInt()
private val PAGE = 0xFFF6F8FC.toInt(); private val LINE = 0xFFDDE3F0.toInt(); private val TINT = 0xFFEEF3FB.toInt()
private val GREEN = 0xFF22925F.toInt(); private val AMBER = 0xFFC27A0E.toInt(); private val RED = 0xFFC8372D.toInt()

class Sub(var held: Int, var a: Int, val recent: MutableList<Int>) { val pct: Double get() = if (held > 0) a * 100.0 / held else 100.0 }
class Student(val name: String, val sub: List<Sub>)
class Task(val title: String, val sub: Int, val done: MutableSet<Int> = mutableSetOf())
class Session(val sub: Int, val code: String, val end: Long, val present: MutableMap<Int, String> = mutableMapOf())

private fun seedStudents(): List<Student> {
    val prof = listOf(Triple("Aarav", 0.92, false), Triple("Diya", 0.88, false), Triple("Kabir", 0.70, true),
        Triple("Meera", 0.96, false), Triple("Rohan", 0.64, true), Triple("Sana", 0.82, false),
        Triple("Tanvi", 0.76, true), Triple("Vikram", 0.58, true))
    val off = listOf(0.0, -0.05, 0.03, -0.02)
    var seed = 7L
    fun rnd(): Double { seed = seed * 16807 % 2147483647; return seed / 2147483647.0 }
    return prof.map { (n, r, decl) ->
        Student(n, SUBJ.indices.map { j ->
            val a = Math.round(24 * (r + off[j])).toInt().coerceIn(8, 24)
            val p = maxOf(0.1, r + off[j] - (if (decl) 0.18 else 0.0))
            Sub(24, a, MutableList(5) { if (rnd() < p) 1 else 0 })
        })
    }
}

private fun risk(x: Sub): Pair<Double, String> {
    val sc = ((TH + 6 - x.pct) / 16 + (0.7 - x.recent.average()) * 0.6).coerceIn(0.0, 1.0)
    return sc to (if (sc >= 0.6) "high" else if (sc >= 0.3) "medium" else "low")
}
private fun need(x: Sub) = maxOf(0, 3 * x.held - 4 * x.a)
private fun lvColor(lv: String) = when (lv) { "high" -> RED; "medium" -> AMBER; else -> GREEN }
private fun tm() = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())

class MainActivity : AppCompatActivity() {
    private val prefs by lazy { getSharedPreferences("smartattend", Context.MODE_PRIVATE) }
    private val matcher by lazy { FaceMatcher(this) }
    private val exec = Executors.newSingleThreadExecutor()
    private val handler = Handler(Looper.getMainLooper())
    private val detector by lazy {
        FaceDetection.getClient(FaceDetectorOptions.Builder()
            .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
            .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_ALL).build())
    }
    // app state (in memory, like the web prototype)
    private val students = seedStudents()
    private val tasks = mutableListOf(Task("Solve 5 linked-list problems", 2, mutableSetOf(0, 1, 3)),
        Task("ER diagram for library system", 3, mutableSetOf(3)))
    private val logs = mutableListOf<String>()
    private var view = "student"; private var me = 7; private var fSub = 0; private var tSub = 0
    private var sess: Session? = null
    private var msg = ""
    // views
    private lateinit var content: LinearLayout
    private lateinit var tabs: LinearLayout
    private lateinit var status: TextView
    private lateinit var preview: PreviewView
    private var cdView: TextView? = null
    // face scan state
    private var provider: ProcessCameraProvider? = null
    private var scanEnroll = false; private var scanFor = 0
    private var eyesOpen = false; private var blinked = false; private var handled = false
    private val camPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        if (it) startCamera() else say("Camera permission is needed for face scan.")
    }

    // ---------- UI helpers ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun bg(fill: Int, r: Int, stroke: Int = 0) = GradientDrawable().apply {
        setColor(fill); cornerRadius = dp(r).toFloat(); if (stroke != 0) setStroke(dp(1), stroke)
    }
    private fun label(t: String, size: Float = 14f, color: Int = INK, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = size; setTextColor(color); if (bold) setTypeface(typeface, Typeface.BOLD)
    }
    private fun btn(t: String, filled: Boolean, a: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; textSize = 15f
        setTextColor(if (filled) Color.WHITE else BLUE)
        background = bg(if (filled) BLUE else Color.TRANSPARENT, 12, if (filled) 0 else BLUE)
        setOnClickListener { a() }
    }
    private fun card(title: String, vararg views: View) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = bg(Color.WHITE, 16, LINE)
        setPadding(dp(16), dp(14), dp(16), dp(14))
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 0, 0, dp(12)) }
        addView(label(title, 16f, INK, true).apply { setPadding(0, 0, 0, dp(8)) })
        views.forEach { addView(it) }
    }
    private fun rowW(left: View, right: View) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
        addView(left, LinearLayout.LayoutParams(0, -2, 1f)); addView(right, LinearLayout.LayoutParams(-2, -2))
    }
    private fun pair(a: View, b: View) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        addView(a, LinearLayout.LayoutParams(0, dp(52), 1f).apply { setMargins(0, 0, dp(6), 0) })
        addView(b, LinearLayout.LayoutParams(0, dp(52), 1f).apply { setMargins(dp(6), 0, 0, 0) })
    }
    private fun pill(t: String, lv: String): TextView {
        val c = lvColor(lv)
        return label(t, 12f, c, true).apply {
            background = bg((c and 0xFFFFFF) or 0x2E000000, 20); setPadding(dp(10), dp(3), dp(10), dp(3))
        }
    }
    private fun bar(p: Double, color: Int = BLUE) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL; background = bg(TINT, 6)
        layoutParams = LinearLayout.LayoutParams(-1, dp(10)).apply { setMargins(0, dp(8), 0, dp(4)) }
        addView(View(context).apply { background = bg(color, 6) }, LinearLayout.LayoutParams(0, -1, p.toFloat().coerceIn(0.1f, 100f)))
        addView(View(context), LinearLayout.LayoutParams(0, -1, (100 - p).toFloat().coerceIn(0.1f, 100f)))
    }
    private fun note(t: String, c: Int) = label(t, 13f).apply {
        background = bg((c and 0xFFFFFF) or 0x1F000000, 8); setPadding(dp(10), dp(8), dp(10), dp(8))
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setTopMargin(this) }
    }
    private fun setTopMargin(p: LinearLayout.LayoutParams) { p.setMargins(0, dp(8), 0, 0) }
    private fun field(hint: String) = EditText(this).apply { this.hint = hint; setTextColor(INK); setHintTextColor(MUTE) }
    private fun spinner(items: List<String>, sel: Int, on: (Int) -> Unit) = Spinner(this).apply {
        adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, items)
        setSelection(sel)
        onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) = on(pos)
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
    }

    override fun onCreate(s: Bundle?) {
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        super.onCreate(s)
        status = label("", 14f).apply {
            background = bg(TINT, 10); setPadding(dp(12), dp(10), dp(12), dp(10))
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(10), 0, dp(6)) }
        }
        preview = PreviewView(this).apply {
            visibility = View.GONE
            layoutParams = LinearLayout.LayoutParams(-1, dp(320)).apply { setMargins(0, 0, 0, dp(8)) }
        }
        tabs = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; background = bg(TINT, 14); setPadding(dp(4), dp(4), dp(4), dp(4))
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 0, 0, dp(12)) }
        }
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background = bg(BLUE, 20)
            setPadding(dp(20), dp(22), dp(20), dp(22))
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 0, 0, dp(12)) }
            addView(label("SmartAttend AI", 26f, Color.WHITE, true))
            addView(label("Attendance by face or fingerprint", 14f, 0xFFD7E3FA.toInt()))
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(40), dp(16), dp(24)); setBackgroundColor(PAGE)
        }
        root.addView(header); root.addView(tabs); root.addView(content)
        setContentView(ScrollView(this).apply { setBackgroundColor(PAGE); addView(root) })
        render(); tick()
    }

    override fun onDestroy() { handler.removeCallbacksAndMessages(null); super.onDestroy() }

    private fun live() = sess?.let { System.currentTimeMillis() < it.end } == true
    private fun countdown(): String {
        val s = sess ?: return ""
        val left = maxOf(0L, (s.end - System.currentTimeMillis()) / 1000)
        return if (left > 0) "Check-in window closes in ${left}s" else "Check-in window closed."
    }
    private fun tick() { handler.postDelayed({ cdView?.text = countdown(); tick() }, 1000) }
    private fun say(t: String) = runOnUiThread { msg = t; status.text = t }

    private fun render() {
        (status.parent as? ViewGroup)?.removeView(status)
        (preview.parent as? ViewGroup)?.removeView(preview)
        cdView = null
        tabs.removeAllViews()
        listOf("student" to "Student", "faculty" to "Faculty", "admin" to "Admin").forEach { (k, l) ->
            tabs.addView(btn(l, view == k) { view = k; msg = ""; render() },
                LinearLayout.LayoutParams(0, dp(46), 1f).apply { setMargins(dp(3), 0, dp(3), 0) })
        }
        content.removeAllViews()
        when (view) { "student" -> studentView(); "faculty" -> facultyView(); else -> adminView() }
    }

    // ---------- Student ----------
    private fun studentView() {
        val st = students[me]
        val tot = st.sub.sumOf { it.a }; val held = st.sub.sumOf { it.held }
        content.addView(card("Viewing as",
            spinner(students.map { it.name }, me) { pos -> if (pos != me) handler.post { me = pos; msg = ""; render() } },
            label("Overall ${"%.0f".format(tot * 100.0 / held)}% · required $TH%", 13f, MUTE)))

        status.text = msg.ifEmpty { "Verify with your face or fingerprint while a session is open." }
        val code = field("Class code").apply {
            filters = arrayOf(InputFilter.LengthFilter(5)); inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
        }
        val ses = if (live()) "Live: ${SUBJ[sess!!.sub]} session is open." else "No session is open right now."
        content.addView(card("Mark attendance in class", label(ses, 13f, if (live()) GREEN else MUTE),
            pair(btn("Scan face", true) { startFace(false) }, btn("Fingerprint", true) { fingerprint() }),
            status, preview,
            btn("Enroll my face (once)", false) { startFace(true) },
            label("Sensor not working? Use the class code:", 13f, MUTE), code,
            btn("Check in with code", false) { codeCheckIn(code.text.toString().trim().uppercase()) }))

        val tv = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        if (tasks.isEmpty()) tv.addView(label("No tasks yet.", 13f, MUTE))
        tasks.forEach { t ->
            tv.addView(rowW(label("${t.title}\n${SUBJ[t.sub]}", 14f),
                if (me in t.done) pill("Done", "low") else btn("Mark done", false) { t.done.add(me); render() }))
        }
        content.addView(card("Tasks from faculty", tv))

        st.sub.forEachIndexed { j, x ->
            val lv = risk(x).second
            val alert = when (lv) {
                "high" -> if (x.pct < TH) "Below $TH%. Attend the next ${need(x)} classes in a row to get back to $TH%."
                          else "Attendance is trending down. A few more absences would take you below $TH%."
                "medium" -> "Close to the $TH% line. Keep attending to stay safe."
                else -> null
            }
            val c = card(SUBJ[j],
                rowW(label("%.0f%%".format(x.pct), 32f, INK, true), pill(lv.replaceFirstChar { it.uppercase() } + " risk", lv)),
                bar(x.pct),
                label("${x.a} of ${x.held} classes · last 5: ${x.recent.joinToString(" ") { if (it == 1) "●" else "○" }} · required $TH%", 13f, MUTE))
            if (alert != null) c.addView(note(alert, lvColor(lv)))
            content.addView(c)
        }
    }

    // ---------- Faculty ----------
    private fun facultyView() {
        val s = sess
        content.addView(card("Class session",
            spinner(SUBJ, fSub) { fSub = it }.apply { isEnabled = s == null },
            if (s == null) btn("Start class session", true) { startSession() } else btn("End session & save", true) { endSession() }))

        val title = field("Task title")
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        tasks.forEach { list.addView(label("${it.title} · ${SUBJ[it.sub]} · ${it.done.size}/${students.size} done", 13f, MUTE)) }
        content.addView(card("Assign a task", spinner(SUBJ, tSub) { tSub = it }, title,
            btn("Assign", true) {
                val t = title.text.toString().trim()
                if (t.isNotEmpty()) { tasks.add(Task(t, tSub)); render() }
            }, list))

        if (s == null) {
            content.addView(card("No session yet", label("Pick a subject and start a session. Students then verify with face, fingerprint or the backup code.", 13f, MUTE)))
            return
        }
        cdView = label(countdown(), 13f, MUTE)
        content.addView(card("${SUBJ[s.sub]} · classroom scanner",
            label("Backup code if a sensor fails:", 13f, MUTE),
            label(s.code, 30f, INK, true).apply { gravity = Gravity.CENTER },
            cdView!!,
            btn("Simulate a student check-in", false) {
                val i = students.indices.firstOrNull { it !in s.present }
                if (i != null && live()) { s.present[i] = tm() + " · " + listOf("Face", "Fingerprint").random(); render() }
            }))
        val rows = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        students.forEachIndexed { i, st ->
            val p = s.present[i]; val lv = risk(st.sub[s.sub]).second
            rows.addView(rowW(
                label("${st.name}\n${"%.0f".format(st.sub[s.sub].pct)}% · $lv risk${if (p != null) " · $p" else ""}", 14f),
                btn(if (p != null) "Present" else "Absent", p != null) {
                    if (p != null) s.present.remove(i) else s.present[i] = tm() + " · Manual"
                    logs.add(0, "${st.name} marked ${if (p != null) "absent" else "present"} in ${SUBJ[s.sub]} by faculty (${tm()})")
                    render()
                }))
        }
        content.addView(card("Live class list (tap to correct)", rows))
    }

    private fun startSession() {
        val chars = "ABCDEFGHJKMNPQRSTUVWXYZ23456789"
        sess = Session(fSub, (1..5).map { chars.random() }.joinToString(""), System.currentTimeMillis() + 90_000)
        msg = ""; render()
    }
    private fun endSession() {
        val s = sess ?: return
        students.forEachIndexed { i, st ->
            val x = st.sub[s.sub]; val p = if (i in s.present) 1 else 0
            x.held++; x.a += p; x.recent.add(p); x.recent.removeAt(0)
        }
        logs.add(0, "${SUBJ[s.sub]} session saved: ${s.present.size} of ${students.size} present (${tm()})")
        sess = null; render()
    }

    // ---------- Admin ----------
    private fun adminView() {
        val bars = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        SUBJ.forEachIndexed { j, n ->
            val p = students.sumOf { it.sub[j].a } * 100.0 / students.sumOf { it.sub[j].held }
            bars.addView(rowW(label(n), label("%.0f%%".format(p), 14f, INK, true))); bars.addView(bar(p))
        }
        content.addView(card("Average attendance by subject", bars, label("Required: $TH%", 13f, MUTE)))

        val all = students.flatMap { st -> st.sub.mapIndexed { j, x -> Triple(st.name, j, x) } }
        val counts = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("low", "medium", "high").forEach { lv ->
            counts.addView(LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                addView(label(all.count { risk(it.third).second == lv }.toString(), 32f, INK, true))
                addView(pill(lv.replaceFirstChar { it.uppercase() }, lv))
            }, LinearLayout.LayoutParams(0, -2, 1f))
        }
        content.addView(card("Risk across all student-subject pairs", counts))

        val fl = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val high = all.filter { risk(it.third).second == "high" }.sortedByDescending { risk(it.third).first }.take(8)
        if (high.isEmpty()) fl.addView(label("No high-risk students.", 13f, MUTE))
        high.forEach { fl.addView(label("${it.first} · ${SUBJ[it.second]} · ${"%.0f".format(it.third.pct)}%", 14f)) }
        content.addView(card("Needs follow-up", fl))

        val ll = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        if (logs.isEmpty()) ll.addView(label("No corrections yet. Changes made on the faculty screen are logged here.", 13f, MUTE))
        logs.take(10).forEach { ll.addView(label("• $it", 13f, MUTE)) }
        content.addView(card("Attendance corrections", ll))
    }

    // ---------- check-in methods ----------
    private fun markPresent(id: Int, method: String) {
        val s = sess
        if (s == null || !live()) return say(if (s == null) "No session is open. Ask your faculty to start one." else "This session’s check-in window has closed.")
        if (id in s.present) return say("You’re already checked in.")
        s.present[id] = tm() + " · " + method
        msg = "Checked in to ${SUBJ[s.sub]} at ${tm()} with $method."
        render()
    }
    private fun codeCheckIn(v: String) {
        val s = sess
        if (s == null || !live()) return say(if (s == null) "No session is open. Ask your faculty to start one." else "That code has expired. Ask your faculty for a new session.")
        if (v != s.code) return say("Code doesn’t match. Check the code on the screen and try again.")
        markPresent(me, "Code")
    }

    private fun fingerprint() {
        if (!live()) return say(if (sess == null) "No session is open. Ask your faculty to start one." else "This session’s check-in window has closed.")
        val who = me
        val can = BiometricManager.from(this).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG)
        if (can != BiometricManager.BIOMETRIC_SUCCESS)
            return say("No usable fingerprint (code $can). Add a fingerprint in Android Settings first.")
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Mark attendance").setSubtitle("Verify with your fingerprint")
            .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG)
            .setNegativeButtonText("Cancel").build()
        BiometricPrompt(this, ContextCompat.getMainExecutor(this), object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(r: BiometricPrompt.AuthenticationResult) = markPresent(who, "Fingerprint")
            override fun onAuthenticationError(c: Int, e: CharSequence) = say("Fingerprint: $e")
            override fun onAuthenticationFailed() = say("Fingerprint not recognised. Try again.")
        }).authenticate(info)
    }

    private fun startFace(enroll: Boolean) {
        if (!matcher.ready) return say("Face model missing. Put mobilefacenet.tflite in app/src/main/assets and rebuild (see README).")
        if (!enroll) {
            if (prefs.getString("emb_$me", null) == null) return say("Enroll your face first.")
            if (!live()) return say(if (sess == null) "No session is open. Ask your faculty to start one." else "This session’s check-in window has closed.")
        }
        scanEnroll = enroll; scanFor = me; eyesOpen = false; blinked = false; handled = false
        if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) startCamera()
        else camPerm.launch(Manifest.permission.CAMERA)
    }

    private fun startCamera() {
        val f = ProcessCameraProvider.getInstance(this)
        f.addListener({
            val p = f.get().also { provider = it }
            val pv = Preview.Builder().build().also { it.setSurfaceProvider(preview.surfaceProvider) }
            val ia = ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
            ia.setAnalyzer(exec) { analyze(it) }
            p.unbindAll()
            p.bindToLifecycle(this, CameraSelector.DEFAULT_FRONT_CAMERA, pv, ia)
            preview.visibility = View.VISIBLE
            say("Look at the camera and blink once.")
        }, ContextCompat.getMainExecutor(this))
    }

    private fun analyze(proxy: ImageProxy) {
        val media = proxy.image
        if (media == null || handled) { proxy.close(); return }
        val img = InputImage.fromMediaImage(media, proxy.imageInfo.rotationDegrees)
        detector.process(img).addOnSuccessListener { faces ->
            if (handled || faces.size != 1) return@addOnSuccessListener
            val l = faces[0].leftEyeOpenProbability ?: 1f
            val r = faces[0].rightEyeOpenProbability ?: 1f
            if (l > 0.8f && r > 0.8f) {
                if (blinked) { handled = true; capture(proxy, faces[0]) } else eyesOpen = true
            } else if (l < 0.3f && r < 0.3f && eyesOpen) blinked = true
        }.addOnCompleteListener { proxy.close() }
    }

    private fun capture(proxy: ImageProxy, face: Face) {
        val raw = proxy.toBitmap()
        val up = Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height,
            Matrix().apply { postRotate(proxy.imageInfo.rotationDegrees.toFloat()) }, true)
        val b = face.boundingBox
        val x = b.left.coerceIn(0, up.width - 1)
        val y = b.top.coerceIn(0, up.height - 1)
        val w = b.width().coerceAtMost(up.width - x).coerceAtLeast(1)
        val h = b.height().coerceAtMost(up.height - y).coerceAtLeast(1)
        val emb = matcher.embed(Bitmap.createScaledBitmap(Bitmap.createBitmap(up, x, y, w, h), 112, 112, true))
        provider?.unbindAll(); preview.visibility = View.GONE
        val who = scanFor
        if (scanEnroll) {
            prefs.edit().putString("emb_$who", emb.joinToString(",")).apply()
            say("Face enrolled for ${students[who].name}.")
        } else {
            val saved = prefs.getString("emb_$who", "")!!.split(",").map { it.toFloat() }.toFloatArray()
            val sim = matcher.similarity(emb, saved)
            if (sim >= MATCH_THRESHOLD) markPresent(who, "Face") else say("Face not recognised (score %.2f). Try again.".format(sim))
        }
    }
}
