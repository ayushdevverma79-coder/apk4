package com.smartattend.app

import android.content.Context
import android.graphics.Bitmap
import org.tensorflow.lite.Interpreter
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.channels.FileChannel
import kotlin.math.sqrt

/** Turns a 112x112 face crop into an embedding with a MobileFaceNet-style TFLite model. */
class FaceMatcher(ctx: Context) {
    private val interp: Interpreter? = try {
        val fd = ctx.assets.openFd("mobilefacenet.tflite")
        val buf = FileInputStream(fd.fileDescriptor).channel
            .map(FileChannel.MapMode.READ_ONLY, fd.startOffset, fd.declaredLength)
        Interpreter(buf)
    } catch (e: Exception) { null }

    val ready: Boolean get() = interp != null

    fun embed(bmp: Bitmap): FloatArray {
        val px = IntArray(112 * 112)
        bmp.getPixels(px, 0, 112, 0, 0, 112, 112)
        val inp = ByteBuffer.allocateDirect(112 * 112 * 3 * 4).order(ByteOrder.nativeOrder())
        for (p in px) {
            inp.putFloat((((p shr 16) and 255) - 127.5f) / 128f)
            inp.putFloat((((p shr 8) and 255) - 127.5f) / 128f)
            inp.putFloat(((p and 255) - 127.5f) / 128f)
        }
        val dim = interp!!.getOutputTensor(0).shape().last()
        val out = Array(1) { FloatArray(dim) }
        interp.run(inp, out)
        val v = out[0]
        val n = sqrt(v.sumOf { (it * it).toDouble() }).toFloat().coerceAtLeast(1e-6f)
        return FloatArray(dim) { v[it] / n }
    }

    fun similarity(a: FloatArray, b: FloatArray): Float {
        var s = 0f
        for (i in a.indices) s += a[i] * b[i]
        return s
    }
}
